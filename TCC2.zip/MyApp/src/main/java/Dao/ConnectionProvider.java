/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Bean.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author pedro
 */
public class ConnectionProvider {

    public static Connection getCon() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/GerenciadorDeDividas", "postgres", "kunga7");
            return con;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectionProvider.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public static class BillCrud {

        public static ResultSet details() throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("Select * from bill");
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            return rs;
        }

        public static Bill search(Bill bill) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("Select * from bill where id = ?");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bill.getId());
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                bill.setProduct_id(rs.getInt(3));
                bill.setBuyer_id(rs.getInt(4));
                bill.setQuantity(rs.getInt(5));
                bill.setSale(rs.getDouble(6));
                bill.setTotal(rs.getDouble(7));
                bill.setPaid(rs.getDouble(8));
                bill.setDebt(rs.getDouble(9));
                bill.setChange(rs.getDouble(10));
            } else {
                JOptionPane.showMessageDialog(null, "Venda nao existe");
            }
            return bill;
        }

        public static void create(Bill bill) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("INSERT INTO bill(date,product,buyer,quantity,sale,total,paid,debt,change) VALUES (?,?,?,?,?,?,?,?,?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setDate(1, bill.getDate());
            pst.setInt(2, bill.getProduct_id());
            pst.setInt(3, bill.getBuyer_id());
            pst.setInt(4, bill.getQuantity());
            pst.setDouble(5, bill.getSale());
            pst.setDouble(6, bill.getTotal());
            pst.setDouble(7, bill.getPaid());
            pst.setDouble(8, bill.getDebt());
            pst.setDouble(9, bill.getChange());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Venda adicionada");
        }

        public static void update(Bill bill) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = "UPDATE bill SET date = ?, product = ?, buyer = ?, quantity = ?, sale = ?, total = ?, paid = ?, debt = ?, change = ? where id = ? ";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setDate(1, bill.getDate());
            pst.setInt(2, bill.getProduct_id());
            pst.setInt(3, bill.getBuyer_id());
            pst.setInt(4, bill.getQuantity());
            pst.setDouble(5, bill.getSale());
            pst.setDouble(6, bill.getTotal());
            pst.setDouble(7, bill.getPaid());
            pst.setDouble(8, bill.getDebt());
            pst.setDouble(9, bill.getChange());
            pst.setInt(10, bill.getId());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Venda atualizada");
        }
        public static void Delete(Bill bill) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("DELETE FROM bill where id=(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bill.getId());
            pst.executeQuery();
        }

        public static boolean verifyBill(Bill bill) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("SELECT * FROM bill WHERE id =(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bill.getId());
            ResultSet rs = pst.executeQuery();
            return rs.next();
        }
    }

    public class BuyerCrud {

        public static void update(Buyer buyer) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = "UPDATE buyer SET name = ? , cellphone = ?, email = ? , address = ?, sex = ? where cpf = ? ";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, buyer.getName());
            pst.setString(2, buyer.getCellphone());
            pst.setString(3, buyer.getEmail());
            pst.setString(4, buyer.getAddress());
            pst.setString(5, buyer.getSex());
            pst.setString(6, buyer.getCPF());
            pst.executeUpdate();
        }

        public static void create(Buyer buyer) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("INSERT INTO buyer(name,cellphone,email,address,sex,CPF) VALUES (?,?,?,?,?,?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, buyer.getName());
            pst.setString(2, buyer.getCellphone());
            pst.setString(3, buyer.getEmail());
            pst.setString(4, buyer.getAddress());
            pst.setString(5, buyer.getSex());
            pst.setString(6, buyer.getCPF());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Cliente adicionado");
        }

        public static Buyer search(Buyer buyer) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("SELECT * FROM buyer WHERE cpf =(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, buyer.getCPF());
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                buyer.setName(rs.getString(2));
                buyer.setCellphone(rs.getString(3));
                buyer.setEmail(rs.getString(4));
                buyer.setAddress(rs.getString(5));
                buyer.setSex(rs.getString(6));
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não existe");
            }
            return buyer;
        }

        public static ResultSet details() throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("Select * from buyer ");
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            return rs;
        }

        public static void Delete(Buyer buyer) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("DELETE FROM buyer where cpf=(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, buyer.getCPF());
            pst.executeQuery();
        }

        public static boolean searchCPF(Buyer buyer) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("SELECT * FROM buyer WHERE cpf =(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, buyer.getCPF());
            ResultSet rs = pst.executeQuery();
            return rs.next();
        }

        public static boolean verifyBuyerId(Bill bill) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("SELECT * FROM buyer WHERE id =(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bill.getBuyer_id());
            ResultSet rs = pst.executeQuery();
            return rs.next();
        }
    }

    public class ProductCrud {

        public static void create(Product product) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("INSERT INTO product(name,brand,value,amount,price) VALUES (?,?,?,?,?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, product.getName());
            pst.setInt(2, product.getBrand());
            pst.setDouble(3, product.getValue());
            pst.setInt(4, product.getAmount());
            pst.setDouble(5, product.getPrice());
            pst.executeUpdate();
        }

        public static Product search(Product product) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("SELECT * FROM product WHERE id =(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, product.getId());
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                product.setName(rs.getString(2));
                product.setBrand(rs.getInt(3));
                product.setValue(rs.getDouble(4));
                product.setAmount(rs.getInt(5));
                product.setPrice(rs.getDouble(6));
            } else {
                JOptionPane.showMessageDialog(null, "Id: " + product.getId() + " não existe");
            }
            return product;
        }

        public static void update(Product product) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = "UPDATE product SET name = ? , brand = ?, value = ? , amount = ?, price = ? where id = ? ";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, product.getName());
            pst.setInt(2, product.getBrand());
            pst.setDouble(3, product.getValue());
            pst.setInt(4, product.getAmount());
            pst.setDouble(5, product.getPrice());
            pst.setInt(6, product.getId());
            pst.executeUpdate();
        }

        public static ResultSet details() throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("Select * from product");
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            return rs;
        }

        public static void Delete(Product product) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("DELETE FROM product where id=(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, product.getId());
            pst.executeQuery();
        }

        public static boolean verifyProductId(Bill bill) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("SELECT * FROM product WHERE id =(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bill.getProduct_id());
            ResultSet rs = pst.executeQuery();
            return rs.next();
        }

        public static boolean updateAmount(Bill bill) throws SQLException {
            boolean update;
            Connection con = ConnectionProvider.getCon();
            Product product_amount = new Product(0, "?", 0, 0, 0, 0);
            String sql_0 = "SELECT amount FROM product WHERE id = ?";
            String sql_1 = "UPDATE product SET amount = ? WHERE id = ? ";
            PreparedStatement pst_0 = con.prepareStatement(sql_0);
            PreparedStatement pst_1 = con.prepareStatement(sql_1);
            pst_0.setInt(1, bill.getProduct_id());
            ResultSet rs = pst_0.executeQuery();
            if (rs.next()) {
                product_amount.setAmount(rs.getInt(1));
                int amount = product_amount.getAmount();
                int quantity = bill.getQuantity();
                pst_1.setInt(1, amount - quantity);
                pst_1.setInt(2, bill.getProduct_id());
                if (amount >= quantity) {
                    pst_1.executeUpdate();
                    update = true;
                } else {
                    JOptionPane.showMessageDialog(null, quantity + " e maior do que a quantia de produtos disponiveis: " + amount);
                    update = false;
                }
            } else {
                JOptionPane.showMessageDialog(null, " update amount erro");
                update = false;
            }
            return update;
        }
    }

    public class BrandCrud {

        public static void create(Brand brand) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("INSERT INTO brand(name) VALUES (?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, brand.getName());
            pst.executeUpdate();
        }

        public static ResultSet search() throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("Select * from brand");
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            return rs;
        }

        public static void delete(Brand brand) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("DELETE FROM brand where id=(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, brand.getId());
            pst.executeQuery();
        }

        public static Boolean verifyBrand(Brand brand) throws SQLException {
            Connection con = ConnectionProvider.getCon();
            String sql = ("SELECT * FROM brand WHERE id =(?)");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, brand.getId());
            ResultSet rs = pst.executeQuery();
            return rs.next();
        }
    }
}
