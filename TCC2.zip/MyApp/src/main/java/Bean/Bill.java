/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bean;

import java.sql.Date;

/**
 *
 * @author pedro
 */
public class Bill {
    private Integer id;
    private Date date;
    private int product_id;
    private int buyer_id;
    private int quantity;
    private double sale;
    private double total;
    private double paid;
    private double debt;
    private double change;
    
    public Bill(Integer id, Date date, int product_id, int buyer_id, int quantity,double sale ,double total,double paid, double debt, double change) {
        this.id = id;
        this.date = date;
        this.product_id = product_id;
        this.buyer_id = buyer_id;
        this.quantity = quantity;
        this.sale = sale;
        this.total = total;
        this.paid = paid;
        this.debt = debt;
        this.change = change;
    }

    public double getChange() {
        return change;
    }

    public void setChange(double change) {
        this.change = change;
    }

    public double getDebt() {
        return debt;
    }

    public void setDebt(double debt) {
        this.debt = debt;
    }

    public double getPaid() {
        return paid;
    }

    public void setPaid(double paid) {
        this.paid = paid;
    }

    public double getSale() {
        return sale;
    }

    public void setSale(double sale) {
        this.sale = sale;
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public int getBuyer_id() {
        return buyer_id;
    }

    public void setBuyer_id(int buyer_id) {
        this.buyer_id = buyer_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    
}
