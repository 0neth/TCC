/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bean;

import Dao.ConnectionProvider;
import java.util.InputMismatchException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import Bean.Bill;
/**
 *
 * @author pedro
 */
public class Verifier {

    public static int VerifyProduct(String id, String name, String price, String brand, String amount, String value) {
        int validation = 0;

        Pattern id_pattern = Pattern.compile("[^0-9]", Pattern.CASE_INSENSITIVE);
        Matcher id_matcher = id_pattern.matcher(id);
        boolean matchIdFound = id_matcher.find();
        if (matchIdFound) {
            validation = 1;
        }

        Pattern name_pattern = Pattern.compile("[^0-9 a-z]", Pattern.CASE_INSENSITIVE);
        Matcher name_matcher = name_pattern.matcher(name);
        boolean matchNameFound = name_matcher.find();
        if (matchNameFound) {
            validation = 2;
        }
        Pattern price_pattern = Pattern.compile("[^0-9 .]", Pattern.CASE_INSENSITIVE);
        Matcher price_matcher = price_pattern.matcher((price));
        boolean matchPriceFound = price_matcher.find();
        if (matchPriceFound) {
            validation = 3;
        }
        Pattern amount_pattern = Pattern.compile("[a-z]", Pattern.CASE_INSENSITIVE);
        Matcher amount_matcher = amount_pattern.matcher((amount));
        boolean matchAmountFound = amount_matcher.find();
        if (matchAmountFound) {
            validation = 4;
        }
        Pattern brandid_pattern = Pattern.compile("[^0-9]", Pattern.CASE_INSENSITIVE);
        Matcher brandid_matcher = brandid_pattern.matcher((brand));
        boolean matchBrandIdFound = brandid_matcher.find();
        if (matchBrandIdFound) {
            validation = 5;
        }
        Pattern value_pattern = Pattern.compile("[^0-9 .]", Pattern.CASE_INSENSITIVE);
        Matcher value_matcher = value_pattern.matcher((value));
        boolean matchValueFound = value_matcher.find();
        if (matchValueFound) {
            validation = 6;
        }
        return validation;
    }

    public static int VerifyBuyer(String id, String name, String cellphone, String email, String address, String CPF, String gender) {
        int validation = 0;
        
        Pattern id_pattern = Pattern.compile("[^0-9]", Pattern.CASE_INSENSITIVE);
        Matcher id_matcher = id_pattern.matcher(id);
        boolean matchIdFound = id_matcher.find();
        if (matchIdFound) {
            validation = 1;
        }
        Pattern name_pattern = Pattern.compile("[0-9]", Pattern.CASE_INSENSITIVE);
        Matcher name_matcher = name_pattern.matcher(name);
        boolean matchNameFound = name_matcher.find();
        if (matchNameFound) {
            validation = 2;
        }
        Pattern cellphone_pattern = Pattern.compile("^(\\(?[0-9]{2}\\)?)? ?([0-9]{4,5})-?([0-9]{4})$", Pattern.CASE_INSENSITIVE);
        Matcher cellphone_matcher = cellphone_pattern.matcher(cellphone);
        boolean matchCellphoneFound = cellphone_matcher.find();
        if (matchCellphoneFound == false) {
            validation = 3;
        }
        Pattern email_pattern = Pattern.compile("^([^\\x00-\\x20\\x22\\x28\\x29\\x2c\\x2e\\x3a-\\x3c\\x3e\\x40\\x5b-\\x5d\\x7f-\\xff]+|\\x22([^\\x0d\\x22\\x5c\\x80-\\xff]|\\x5c[\\x00-\\x7f])*\\x22)(\\x2e([^\\x00-\\x20\\x22\\x28\\x29\\x2c\\x2e\\x3a-\\x3c\\x3e\\x40\\x5b-\\x5d\\x7f-\\xff]+|\\x22([^\\x0d\\x22\\x5c\\x80-\\xff]|\\x5c[\\x00-\\x7f])*\\x22))*\\x40([^\\x00-\\x20\\x22\\x28\\x29\\x2c\\x2e\\x3a-\\x3c\\x3e\\x40\\x5b-\\x5d\\x7f-\\xff]+|\\x5b([^\\x0d\\x5b-\\x5d\\x80-\\xff]|\\x5c[\\x00-\\x7f])*\\x5d)(\\x2e([^\\x00-\\x20\\x22\\x28\\x29\\x2c\\x2e\\x3a-\\x3c\\x3e\\x40\\x5b-\\x5d\\x7f-\\xff]+|\\x5b([^\\x0d\\x5b-\\x5d\\x80-\\xff]|\\x5c[\\x00-\\x7f])*\\x5d))*$", Pattern.CASE_INSENSITIVE);
        Matcher email_matcher = email_pattern.matcher(email);
        boolean matchEmailFound = email_matcher.find();
        if (matchEmailFound == false) {
            validation = 4;
        }
        Pattern address_pattern = Pattern.compile("[^ A-Z 0-9 ç]", Pattern.CASE_INSENSITIVE);
        Matcher address_matcher = address_pattern.matcher(address);
        boolean matchAddressFound = address_matcher.find();
        if (matchAddressFound) {
            validation = 5;
        }
        Pattern gender_pattern = Pattern.compile("^1|2", Pattern.CASE_INSENSITIVE);
        Matcher gender_matcher = gender_pattern.matcher(gender);
        boolean matchGenderFound = gender_matcher.find();
        if (matchGenderFound) {
            validation = 6;
        }
        return validation;
    }

    public static int VerifyBill(String id,String product_id, String buyer_id, String quantity, String sale){
        int validation = 0;
        
        Pattern id_pattern = Pattern.compile("[^0-9]", Pattern.CASE_INSENSITIVE);
        Matcher id_matcher = id_pattern.matcher(id);
        boolean matchIdFound = id_matcher.find();
        if (matchIdFound) {
            validation = 1;
        }
        Pattern product_id_pattern = Pattern.compile("[^ 0-9]", Pattern.CASE_INSENSITIVE);
        Matcher product_id_matcher = product_id_pattern.matcher(product_id);
        boolean matchProductIdFound = product_id_matcher.find();
        if (matchProductIdFound) {
            validation = 2;
        }
        Pattern buyer_id_pattern = Pattern.compile("[^ 0-9]", Pattern.CASE_INSENSITIVE);
        Matcher buyer_id_matcher = buyer_id_pattern.matcher(buyer_id);
        boolean matchBuyerIdFound = buyer_id_matcher.find();
        if (matchBuyerIdFound) {
            validation = 3;
        }
        Pattern quantity_pattern = Pattern.compile("[^ 0-9]", Pattern.CASE_INSENSITIVE);
        Matcher quantity_matcher = quantity_pattern.matcher(quantity);
        boolean matchQuantityIdFound = quantity_matcher.find();
        if (matchQuantityIdFound) {
            validation = 5;
        }
        Pattern sale_pattern = Pattern.compile("[^ 0-9 .]", Pattern.CASE_INSENSITIVE);
        Matcher sale_matcher = sale_pattern.matcher(sale);
        boolean matchSaleIdFound = sale_matcher.find();
        if (matchSaleIdFound) {
            validation = 7;
        }
        return validation;
        
    }
    
    public static boolean isCPF(String CPF) {
        if (CPF.equals("00000000000")
                || CPF.equals("11111111111")
                || CPF.equals("22222222222") || CPF.equals("33333333333")
                || CPF.equals("44444444444") || CPF.equals("55555555555")
                || CPF.equals("66666666666") || CPF.equals("77777777777")
                || CPF.equals("88888888888") || CPF.equals("99999999999")
                || (CPF.length() != 11)) {
            return false;
        }
        char dig10, dig11;
        int sm, i, r, num, peso;
        try {
            sm = 0;
            peso = 10;
            for (i = 0; i < 9; i++) {
                num = (int) (CPF.charAt(i) - 48);
                sm = sm + (num * peso);
                peso = peso - 1;
            }
            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11)) {
                dig10 = '0';
            } else {
                dig10 = (char) (r + 48);
            }
            sm = 0;
            peso = 11;
            for (i = 0; i < 10; i++) {
                num = (int) (CPF.charAt(i) - 48);
                sm = sm + (num * peso);
                peso = peso - 1;
            }
            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11)) {
                dig11 = '0';
            } else {
                dig11 = (char) (r + 48);
            }
            if ((dig10 == CPF.charAt(9)) && (dig11 == CPF.charAt(10))) {
                return true;
            } else {
                return false;
            }
        } catch (InputMismatchException erro) {
            return false;
        }
    }
}
